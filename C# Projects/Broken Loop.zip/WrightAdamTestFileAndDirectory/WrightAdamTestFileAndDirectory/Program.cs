﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using System.IO;


namespace WrightAdamTestFileAndDirectory
{
    class Program
    {
        static void Main(string[] args)
        {
            Directory.CreateDirectory("C:\\Assignments");
            Directory.CreateDirectory("C:\\Students");
            Directory.CreateDirectory("C:\\Resources");
            Directory.CreateDirectory("C:\\Projects");



            File.Create("C:\\Assignments\\Session1");
            File.Create("C:\\Assignments\\Session2");
            File.Create("C:\\Assignments\\Session3");

            File.Create("C:\\Students\\Adam");
            File.Create("C:\\Students\\Mark");
            File.Create("C:\\Students\\Josh");
            File.Create("C:\\Students\\Matt");

            File.Create("C:\\Resources\\Syllabus");
            File.Create("C:\\Resources\\Learning Center");
            File.Create("C:\\Resources\\Tutoring");

            File.Create("C:\\Projects\\Project1");
            File.Create("C:\\Projects\\Project2");
            File.Create("C:\\Projects\\Project3");


            String fileName;
       
            WriteLine("Enter a file name");
            fileName = ReadLine();


            if (File.Exists(fileName))
            {
                WriteLine("This is a valid file extension.");
                WriteLine("File was created" + File.GetCreationTime(fileName));
                WriteLine("File was last accessed" + File.GetLastAccessTime(fileName));
                WriteLine("File was last written too" + File.GetLastWriteTime(fileName));
            }

            else if (Directory.Exists(fileName))
            {
                WriteLine("This is a valid file extension.");
                WriteLine("File was created" + File.GetCreationTime(fileName));
                WriteLine("File was last accessed" + File.GetLastAccessTime(fileName));
                WriteLine("File was last written too" + File.GetLastWriteTime(fileName));
            }

            else
            {
                WriteLine("This File or directory does not exist");
            }
         


        }
    }
}
    


