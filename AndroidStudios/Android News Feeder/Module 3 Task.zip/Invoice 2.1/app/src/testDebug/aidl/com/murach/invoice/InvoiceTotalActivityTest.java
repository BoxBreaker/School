package com.murach.invoice;

import junit.framework.TestCase;

/**
 * Created by adamwright on 2/4/18.
 */
public class InvoiceTotalActivityTest extends TestCase {

}