package student.newsfeeder;

public class activity_settings {



}
