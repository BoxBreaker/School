package student.newsfeeder;

import static org.junit.Assert.*;

public class BreakingNewsTest {

}